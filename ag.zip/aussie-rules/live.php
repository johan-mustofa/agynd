<?php include('../header.php');?>
  <body data-spy="scroll" data-target=".onpage-navigation" data-offset="60">
    <main>
              <?php include('../menu.php');?>
                    <div class="main"><section class="">
  <div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-2 col-md-2 sidebar">
            <div class="widget">
                <marquee><h5 class="font-alt"><?php echo $meta_title;?> Aussie Rules</h5></marquee>
                <h5 class="widget-title font-alt">Sport</h5>
                <ul class="icon-list">
                                  <li><a href="<?php echo $url_webs;?>Aussie Rules/live" style="cursor:pointer" class="select-state">Aussie Rules</a></li>
                                  <li><a href="<?php echo $url_webs;?>Badminton/live" style="cursor:pointer" class="select-state">Badminton</a></li>
                                  <li><a href="<?php echo $url_webs;?>Bandy/live" style="cursor:pointer" class="select-state">Bandy</a></li>
                                  <li><a href="<?php echo $url_webs;?>Beach Volley/live" style="cursor:pointer" class="select-state">Beach Volley</a></li>
                                  <li><a href="<?php echo $url_webs;?>Baseball/live" style="cursor:pointer" class="select-state">Baseball</a></li>
                                  <li><a href="<?php echo $url_webs;?>Basket/live" style="cursor:pointer" class="select-state">Basket</a></li>
                                  <li><a href="<?php echo $url_webs;?>Cricket/live" style="cursor:pointer" class="select-state">Cricket</a></li>
                                  <li><a href="<?php echo $url_webs;?>Darts/live" style="cursor:pointer" class="select-state">Darts</a></li>
                                  <li><a href="<?php echo $url_webs;?>Esports/live" style="cursor:pointer" class="select-state">Esports</a></li>
                                  <li><a href="<?php echo $url_webs;?>Floorball/live" style="cursor:pointer" class="select-state">Floorball</a></li>
                                  <li><a href="<?php echo $url_webs;?>Futsal/live" style="cursor:pointer" class="select-state">Futsal</a></li>
                                  <li><a href="<?php echo $url_webs;?>Handball/live" style="cursor:pointer" class="select-state">Handball</a></li>
                                  <li><a href="<?php echo $url_webs;?>Football/live" style="cursor:pointer" class="select-state">Football</a></li>
                                  <li><a href="<?php echo $url_webs;?>Ice Hockey/live" style="cursor:pointer" class="select-state">Hockey</a></li>
                                  <li><a href="<?php echo $url_webs;?>Motorsport/live" style="cursor:pointer" class="select-state">Motorsport</a></li>
                                  <li><a href="<?php echo $url_webs;?>Rugby/live" style="cursor:pointer" class="select-state">Rugby</a></li>
                                  <li><a href="<?php echo $url_webs;?>Snooker/live" style="cursor:pointer" class="select-state">Snooker</a></li>
                                  <li><a href="<?php echo $url_webs;?>Soccer/live" style="cursor:pointer" class="select-state">Soccer</a></li>
                                  <li><a href="<?php echo $url_webs;?>Tennis/live" style="cursor:pointer" class="select-state">Table Tennis</a></li>
                                  <li><a href="<?php echo $url_webs;?>Tennis/live" style="cursor:pointer" class="select-state">Tennis</a></li>
                                  <li><a href="<?php echo $url_webs;?>Volley/live" style="cursor:pointer" class="select-state">Volley</a></li>>
                                  <li><a href="<?php echo $url_webs;?>Waterpolo/live" style="cursor:pointer" class="select-state">Waterpolo</a></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-8 col-md-10 col-md-10">
          <div id="schedule" class="row">
            <h4 class="font-alt mb-0"><i class="fa fa-angle-double-right"></i> Live Events</h4>
            <hr class="divider-w mt-10 mb-20">
              <div class="col-12">
                <?php 
   /*
   | -------------------------------------------------------------------------------
   | Author            : G-Silvers
   | Template Name     : G-Silvers Sports Landing Page Special
   | -------------------------------------------------------------------------------
   */
include("../app/grab.php");?>
                <?php 
                  $html = file_get_html('https://api.sofascore.app/api/v1/sport/aussie-rules/events/live');
    $data =  json_decode($html,true);
    
foreach($data['events'] as $elem)  {
    $league = $elem['tournament']['name'];
    $category = $elem['tournament']['category']['name'];
    $sport = $elem['tournament']['category']['sport']['name'];
    $usercount = $elem['tournament']['uniqueTournament']['userCount'];
    $description = $elem['status']['description'];
    $first_title = $elem['homeTeam']['name'];
    $first_logo = 'https://api.sofascore.app/api/v1/team/'.$elem['homeTeam']['id'].'/image';
    $homescore = $elem['homeScore']['current'];
    $status = $elem['status']['type'];
    $second_title = $elem['awayTeam']['name'];
    $second_logo = 'https://api.sofascore.app/api/v1/team/'.$elem['awayTeam']['id'].'/image';
    $awayscore = $elem['awayScore']['current'];
    $slug = $elem['slug'];
    $dt = $elem['startTimestamp'];
    $id = $elem['id'];
        $background_image = $url_webs . "/player/backdrop.jpg";
    $date = new DateTime;
    $date->setTimestamp($dt);
    $dates = $date->format('D, j M Y g:i A | T | e');


                ?>
                                <div class="col-sm-12 col-md-6 col-lg-6 gsilvers">
                  <a href="<?php echo $url_webs;?><?php echo $sport;?>/live/<?php echo $slug;?>/<?php echo $id;?>" class="btn-detail" data-key="<?php echo $id;?>">
                      <div class="post-thumbnail">
                          <div class="gallery-item">
                            <div class="gallery-image">
                              <img src="<?php echo $background_image;?>" alt="<?php echo $sl;?>">
                              <div class="gallery-logo-kiri">
                                <img src="<?php echo $first_logo;?>" alt="<?php echo $first_title;?>">
                              </div>
                              <div class="gallery-logo-kanan">
                                <img src="<?php echo $second_logo;?>" alt="<?php echo $second_title;?>">
                              </div>
                              <div class="gallery-caption">
                                <div class="gallery-icon"><span class="fa fa-play-circle-o"></span></div>
                              </div>
                            </div>
                          </div>
                      </div>
                    <h4 class="menu-title font-alt"><img src="<?php echo $first_logo;?>"/> <?php echo $first_title;?></h4>                    
                    <h4 class="menu-title font-alt"><img src="<?php echo $second_logo;?>"/> <?php echo $second_title;?></h4>                    
                    <div class="menu-detail font-serif"><?php echo $description;?> | <?php echo $category;?> | <?php echo $status;?> </div>
                    <div class="menu-detail font-serif"><?php echo $dates;?> </div>
                  </a>
                </div>
                <?php 
                  }
                  ?>
                    <div class="Cell-sc-t6h3ns-0 iqwpGQ" style="width: 100%; height: 360px; flex-direction: column; padding: 16px;">
                      <div style="color: rgb(128, 128, 128); margin: 0px 0px 4px; text-align: center;"><p>There are no live events at the moment</p><p>Please check again later. <br>Meanwhile, <a href="<?php echo $url_webs;?>">here</a> is the list of all <span style="text-transform: lowercase;">Sports</span> events for today.</p>
                      </div>
                    </div>
                              </div>
          </div>
        </div>
    </div>
  </div>
</section>
<?php include('../footer.php');?>