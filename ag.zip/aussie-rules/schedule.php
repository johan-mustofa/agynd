<?php include('../header.php');?>
  <body data-spy="scroll" data-target=".onpage-navigation" data-offset="60">
    <main>
              <?php include('../menu.php');?>
                    <div class="main"><section class="">
  <div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-2 col-md-2 sidebar">
            <div class="widget">
                <marquee><h5 class="font-alt"><?php echo $meta_title;?> Aussie Rules</h5></marquee>
                <h5 class="widget-title font-alt">Find Schedule by Date</h5>
                <form action="">
                  <label for="date">Schedule Calendar:</label>
                  <input style="background-color:#002241c4" type="date" id="date" name="date">
                  <input style="background-color:#002241c4" type="submit">
                </form>
            </div>
        </div>
        <div class="col-sm-8 col-md-10 col-md-10">
          <div id="schedule" class="row">
            <h4 class="font-alt mb-0"><i class="fa fa-angle-double-right"></i> Schedule Events</h4>
            <hr class="divider-w mt-10 mb-20">
              <div class="col-12">
                <?php 
   /*
   | -------------------------------------------------------------------------------
   | Author            : G-Silvers
   | Template Name     : G-Silvers Sports Landing Page Special
   | -------------------------------------------------------------------------------
   */
include("../app/grab.php");?>
                <?php 
                if( isset($_GET['date']) ) { $_GET['date'];
                if( empty($_GET['date']) ) {

                    $_GET['date'] = date("Y-m-d");

                }
                }
                elseif( empty($_GET['date']) ) {
                    $_GET['date'] = date("Y-m-d");
                }
                
                  $html = file_get_html("https://api.sofascore.app/api/v1/sport/aussie-rules/scheduled-events/$_GET[date]");
    $data =  json_decode($html,true);
    
foreach($data['events'] as $elem)  {
    $league = $elem['tournament']['name'];
    $category = $elem['tournament']['category']['name'];
    $sport = $elem['tournament']['category']['sport']['name'];
    $usercount = $elem['tournament']['uniqueTournament']['userCount'];
    $description = $elem['status']['description'];
    $first_title = $elem['homeTeam']['name'];
    $first_logo = 'https://api.sofascore.app/api/v1/team/'.$elem['homeTeam']['id'].'/image';
    $homescore = $elem['homeScore']['current'];
    $status = $elem['status']['type'];
    $second_title = $elem['awayTeam']['name'];
    $second_logo = 'https://api.sofascore.app/api/v1/team/'.$elem['awayTeam']['id'].'/image';
    $awayscore = $elem['awayScore']['current'];
    $slug = $elem['slug'];
    $dt = $elem['startTimestamp'];
    $id = $elem['id'];
        $background_image = $url_webs . "/player/backdrop.jpg";
    $date = new DateTime;
    $date->setTimestamp($dt);
    $dates = $date->format('D, j M Y g:i A | T | e');



                ?>
                                <div class="col-sm-12 col-md-6 col-lg-6 gsilvers">
                  <a href="<?php echo $url_webs;?><?php echo $sport;?>/live/<?php echo $slug;?>/<?php echo $id;?>" class="btn-detail" data-key="<?php echo $id;?>">
                    <h4 class="menu-title font-alt"><img src="<?php echo $first_logo;?>"/> <?php echo $first_title;?></h4>                    
                    <h4 class="menu-title font-alt"><img src="<?php echo $second_logo;?>"/> <?php echo $second_title;?></h4>                    
                    <div class="menu-detail font-serif"><?php echo $league;?> | <?php echo $category;?> | <?php echo $description;?>/<?php echo $status;?> </div>
                    <div class="menu-detail font-serif"><?php echo $dates;?> </div>
                    <br>((LIVE)) <?php echo $first_title;?> vs <?php echo $second_title;?> 🔴 - FULL GAME
<br>🔴 LIVE: <?php echo $first_title;?> vs <?php echo $second_title;?> (LIVE STREAMING)
<br>((LIVE)) <?php echo $second_title;?> vs. <?php echo $first_title;?> 🔴 <?php echo $first_shortname;?> vs <?php echo $second_shortname;?> | Game 3
<br>LIVE : <?php echo $first_title;?> vs <?php echo $second_title;?> Live Stream 2022 <?php echo $league;?>
<br>(LIVE NOW) <?php echo $first_title;?> vs <?php echo $second_title;?> Live Stream HD | 2022 <?php echo $league;?>
<br>Live: <?php echo $first_title;?> vs <?php echo $second_title;?> - <?php echo $league;?> 2022 Full Game
<br><?php echo $first_title;?> vs <?php echo $second_title;?> | <?php echo $league;?> 2022 'Live Full Game'
<br><?php echo $first_title;?> vs. <?php echo $second_title;?> 🔴 <?php echo $league;?> LIVE HD (<?php echo $dates;?>) FULL GAME
<br>
<br>
<br>https://online.playingstream.net/<?php echo $league;?>/live/<?php echo $first_title;?> vs <?php echo $second_title;?>/<?php echo $id;?>/&i=img&sport=
<br>
<br><?php echo $first_title;?> vs <?php echo $second_title;?> Game 3 Live Stream
<br>Watch Live at 4k :
<br>
<br>Team : <?php echo $first_title;?> vs <?php echo $second_title;?>
<br>Game : <?php echo $league;?> 2022
<br>Date : <?php echo $dates;?>
<br>
<br>
<br><?php echo $second_title;?> at <?php echo $first_title;?> Live
<br><?php echo $second_title;?> vs. <?php echo $first_title;?> Live Match
<br><?php echo $first_title;?> vs <?php echo $second_title;?> Live Stream
<br>Watch <?php echo $first_title;?> vs <?php echo $second_title;?> Live Game
<br>Live Stream <?php echo $league;?> <?php echo $first_title;?> vs <?php echo $second_title;?>
<br><?php echo $first_title;?> vs <?php echo $second_title;?> Live Stream <?php echo $league;?> 2022
<br><?php echo $first_title;?> vs <?php echo $second_title;?> <?php echo $league;?> Live Stream
<br><?php echo $league;?> Live Game 2022: <?php echo $first_title;?> vs <?php echo $second_title;?>
<br><?php echo $first_title;?> vs <?php echo $second_title;?> Full Game
<br><?php echo $first_title;?> vs <?php echo $second_title;?> Live Broadcast
<br>
<br>
<br>
<br>#<?php echo $league;?>
<br>
<br>
<br>
<br>
<br>==========================================
<br>
<br>
<br>
<br>
<br>
<br>
                  </a>
                </div>
                <?php 
                  }
                  ?>
                  <p class="gagal text-center mt-50"><?php echo 'There are no live events at the moment';?></p>
                              </div>
          </div>
        </div>
    </div>
  </div>
</section>
<?php include('../footer.php');?>