<?php include('header.php');?>
  <body data-spy="scroll" data-target=".onpage-navigation" data-offset="60">
    <main>
      <div class="page-loader">
        <div class="loader">Loading...</div>
      </div>
              <?php include('menu.php');?>
                    <div class="main"><h2 class="text-center">HS-SPORTS DIGITAL</h2>
<div class="container">
<p><?php echo $logo;?> Digital, a division of HS Interactive, covers the full spectrum of sports, from preps to pros, and provides premium content across all digital screens. With a focus on serving fans live coverage every day, <?php echo $logo;?> Digital offers exclusive access to the biggest sports events, live and on-demand video, in-depth analysis, breaking news, scores and statistics, and a wide range of fantasy games and advice. <?php echo $logo;?> Digital's multi-platform offerings include HSSports.com and the <?php echo $logo;?> apps for mobile and connected TV devices and All channel SportsLive. a division of HS Corporation, is the world's largest publisher of free digital content and a perennial top 10 internet company.</p>
<p><?php echo $logo;?> 24-hour streaming sports news network offering news, highlights and analysis, easily accessible for free on connected devices. The digital network is a collaboration between <?php echo $logo;?> Interactive and allows sports fans to watch full-day, live, anchored coverage featuring game breakdowns and the day's top sports storylines. <?php echo $logo;?> is currently available on your device. the <?php echo $logo;?> app for key connected TV devices including All channel in the world, the <?php echo $logo;?> mobile app for iOS and Android free service.</p>
</div>

<?php include('footer.php');?>