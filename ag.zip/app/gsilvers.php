<?php /*
   | -------------------------------------------------------------------------------
   | Author            : G-Silvers
   | Template Name     : G-Silvers Sports Landing Page Special
   | -------------------------------------------------------------------------------
*/
require ("grab.php");
        $html = file_get_html("https://api.sofascore.app/api/v1/event/$_GET[gsilvers]");
    $data =  json_decode($html,true);
    $gs = $data['event'];


    $league = $gs['tournament']['name'];
    $category = $gs['tournament']['category']['name'];
    $season = $gs['season']['name'];
    $sport = $gs['tournament']['category']['sport']['name'];

    $description = $gs['status']['description'];
    if ($city){
    $city = $gs['venue']['city']['name'];
    }
    elseif(empty($city)){
    $city = "-";
    }
    if ($stadium){
    $stadium = $gs['venue']['stadium']['name'];
    }
    elseif(empty($stadium)){
    $stadium = "-";
    }
    if ($country){
    $country = $gs['venue']['country']['name'];
    }
    elseif(empty($country)){
    $country = $gs['homeTeam']['country']['name'];
    }
    $first_shortname = $gs['homeTeam']['nameCode'];
    $first_name = $gs['homeTeam']['name'];
    $first_logo = "https://api.sofascore.app/api/v1/team/". $gs['homeTeam']['id']."/image";
    $homescore = $gs['homeScore']['current'];
   
    $status = $gs['status']['type'];

    $second_shortname = $gs['awayTeam']['nameCode'];
    $second_name = $gs['awayTeam']['name'];
    $second_logo = "https://api.sofascore.app/api/v1/team/". $gs['awayTeam']['id']."/image";
    $awayscore = $gs['awayScore']['current'];
    if ($season_type){
    $season_type = $gs['seasonStatisticsType'];
    }
    elseif(empty($season_type)){
    $season_type = "-";
    }
    $background_image = "/player/backdrop.png";

    $customId = $gs['customId'];
    $dt = $gs['startTimestamp'];
    $date = new DateTime;
    $date->setTimestamp($dt);
    $dates = $date->format('D, j M Y g:i A | T | e');

    $gsilvers = file_get_html('https://www.sofascore.com/gsilvers/ItbsLtb');
    $desc = $gsilvers->find("meta[name=description]",0) ->getAttribute('content');
    json_last_error_msg();