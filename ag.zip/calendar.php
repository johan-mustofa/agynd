<form action="/action_page.php">
  <label for="date">Schedule Calendar:</label>
  <input type="date" id="date" name="date">
  <input type="submit">
</form>